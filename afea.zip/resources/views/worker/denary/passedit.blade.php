@extends('layout.worker')

@section('css')
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/workers/css/style_calendar.css')  }}">
    <link rel="stylesheet" href="{{ asset('assets/workers/css/DataTable.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/workers/css/datatable-extension.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/workers/css/datatables.css') }}">
@endsection


@section('bread_crumbs')

    <div #poloska>
        <div id="stud">Журнал учета посещяемости</div>
        <div id="road">
            <i class="roadIcon" data-feather="home"></i>
            <a href="Posesenie.html">Главная &nbsp;</a>/
            <a href="student-edit.html">&nbsp; Деаканат &nbsp;</a>/
            <a href="student-edit.html">&nbsp; {{ $date }}</a>
        </div>
    </div>

@endsection


@section('content')
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <div id="btnBack" class="btnDay"><span>Назад</span></div>
                <input id="date" type="date" value="{{ $date }}">
                <div id="btnNext" class="btnDay"><span>Вперед</span></div>
            </div>
            <div class="card-body">
                <div class="dt-ext table-responsive" id="tablePDF">
                    <table class="display" id="export-button">
                        <thead>
                        <tr>
                            <th>ФИО студента</th>
                            <th>1 пара</th>
                            <th>2 пара</th>
                            <th>3 пара</th>
                            <th>4 пара</th>
                            <th>5 пара</th>
                            <th>Общее</th>
                            <th>За семестр</th>
                        </tr>
                        </thead>
                        <tbody id="fuck">
                        @foreach($group->studentsGroup as $student)
                            <tr>
                                <td>{{ $student->name }} {{ $student->surname }} {{ $student->patronymic }}</td>
                                <td>
                                    {!!  \App\Models\Pass::passForm($passes->where('student_id',$student->id)->where('lesson_part',1)) !!}
                                </td>
                                <td>
                                    {!! \App\Models\Pass::passForm($passes->where('student_id',$student->id)->where('lesson_part',2)) !!}
                                </td>
                                <td>
                                    {!! \App\Models\Pass::passForm($passes->where('student_id',$student->id)->where('lesson_part',3)) !!}
                                </td>
                                <td>
                                    {!! \App\Models\Pass::passForm($passes->where('student_id',$student->id)->where('lesson_part',4)) !!}
                                </td>
                                <td>
                                    {!!   \App\Models\Pass::passForm($passes->where('student_id',$student->id)->where('lesson_part',5)) !!}
                                </td>
                                <td>5</td>
                                <td>8</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('js')
    <!-- Скрипты для таблицы -->
    <script src="{{ asset('assets/workers/js/datatable/datatables/jquery.dataTables.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/dataTables.buttons.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/jszip.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/buttons.colVis.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/pdfmake.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/vfs_fonts.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/dataTables.autoFill.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/dataTables.select.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/buttons.bootstrap4.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/buttons.html5.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/buttons.print.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/dataTables.bootstrap4.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/dataTables.responsive.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/responsive.bootstrap4.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/dataTables.keyTable.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/dataTables.colReorder.min.js') }} "></script>
    <script
        src="{{ asset('assets/workers/js/datatable/datatable-extension/dataTables.fixedHeader.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/dataTables.rowReorder.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/dataTables.scroller.min.js') }} "></script>
    <script src="{{ asset('assets/workers/js/datatable/datatable-extension/custom.js') }} "></script>
    <script src="{{ asset('assets/workers/js/tooltip-init.js') }} "></script>

    <script src="{{ asset('assets/workers/js/DataTable.js') }} "></script>
    <script src="{{ asset('assets/workers/js/dataTables.bootstrap4.min.js') }} "></script>
    <script>

        $("#date").change(function () {
            var date = document.getElementById('date').value;
            var url_first = '{{ route('pass.edit',['group'=>$group]) }}';
            var url_two = `?date=${date}`;
            var fullurl = url_first + url_two;
            console.log(fullurl);
            window.location.replace(fullurl);
        });
    </script>
@endsection


